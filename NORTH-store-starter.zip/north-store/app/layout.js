export const metadata={title:'NORTH — Selected Goods',description:'Ropa, sneakers y accesorios seleccionados'};
export default function RootLayout({children}){return <html lang="es"><body>{children}</body></html>}
